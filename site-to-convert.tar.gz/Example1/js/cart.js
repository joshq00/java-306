
$(document).ready(function(){

	$("#btnSearch").click(execSearch);
	$("#search").keypress(function(event){
		if (event.keyCode == 13){
			execSearch();
		}
	});


	/* load the default data into the cart */
	$.get("json/cartList.json", "", function(data, status, xhr){

		/* skipping status checks for demo only */
		processCartResult(data);
	}, "json");

});


function processCartResult(data){

	/* process each record */
	$(data.skus).each(function(i, item){
		appendItem(item);
	});

	updateTotal();
}

function appendItem(item){
	$("#dataTable tbody").append(function(){

		var cartItem = $("#cartItemTemplate").clone();
		
		//prevent duplicate IDs
		$(cartItem).removeAttr("id");

		//add data
		$(cartItem).data("item", item);

		//update info
		$(cartItem).find(".skuImage").attr("src", item.imageS);
		$(cartItem).find(".description").append(item.descr);
		$(cartItem).find(".sku").append(item.sku);
		$(cartItem).find(".price").append("$" + item.price);
		$(cartItem).find(".uom").append(" / " + item.uom);
		$(cartItem).find(".stock").append(item.onhand);

		return cartItem;
		
	});
}

function removeItem(item){
	item.parentElement.parentElement.remove();
	updateTotal();
}


function execSearch(event){
	
	var term = $("#search").val();
	if(term == ""){
		alert("You must enter a search term");
		return;
	}

	/* get the data */
	$.get("json/skuList.json", "", function(data, status, xhr){

		/* skipping status checks for demo only */
		if (data.skus[term]){
			appendItem(data.skus[term]);
		}else{
			appendItem(data.skus[0]);
		}

		updateTotal();


	}, "json");


}

function updateTotal(){
	var total = 0;
	$(".cartItem").each(function(i, record){
		var item = $(record).data("item");
		if(item != undefined){
			total += item.price;
		}
		
	})

	$("#total").html("$" + total.toFixed(2));
}



